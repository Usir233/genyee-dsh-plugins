/** Decoded access code. */
export interface AccessCode {
    /** Relay origin, `https://host:port` (or `http://` for a relay serving plain HTTP). */
    readonly relayURL: string;
    /** Lowercase hex SHA-256 fingerprint of the relay certificate; absent for plain HTTP. */
    readonly fingerprint: string | undefined;
    /** The employee's authorization token. */
    readonly token: string;
}
/**
 * Normalize a certificate fingerprint written with or without colons, in either case.
 * @param value - fingerprint text, such as Node's `fingerprint256`.
 * @returns lowercase hex without separators.
 */
export declare function normalizeFingerprint(value: string): string;
/**
 * Generate a new authorization token.
 * @returns `gk_` followed by 256 random bits in base64url.
 */
export declare function generateToken(): string;
/**
 * Encode an access code.
 * @param code - relay address, fingerprint, and token.
 * @returns the pasteable access code.
 */
export declare function encodeAccessCode(code: AccessCode): string;
/**
 * Decode and validate an access code.
 * @param text - the pasted access code; surrounding whitespace is ignored.
 * @returns the decoded fields.
 * @throws Error when the code is malformed, names a non-HTTP(S) origin, or pairs HTTPS without a fingerprint.
 */
export declare function decodeAccessCode(text: string): AccessCode;
