/** Admin role: serve the relay over HTTPS (or explicitly plain HTTP) and enforce the ledger. */
import type { Context } from '@deepseek-ai/cordis';
import type { AdminConfig } from '../config.ts';
/**
 * Reject wildcard and non-literal listen addresses.
 * @param host - the configured listen address.
 * @throws Error when `host` is not one concrete IP literal.
 */
export declare function assertConcreteHost(host: string): void;
/**
 * Start the admin role.
 * @param ctx - the plugin context owning the ledger, the listener, and the ledger watch.
 * @param config - admin settings.
 */
export declare function applyAdmin(ctx: Context, config: AdminConfig): Promise<void>;
