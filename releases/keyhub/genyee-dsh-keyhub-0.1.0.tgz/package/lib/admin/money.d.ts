/** Money units, prices, request cost, and quota periods of the admin ledger. */
import type { TokenUsage } from './usage.ts';
/**
 * Amounts are integers in micro-yuan (0.000001 元). Prices are integers in
 * 0.0001 元 per million tokens, so one request's cost is exact before the
 * single rounding to micro-yuan.
 */
export declare const MICROS_PER_YUAN = 1000000;
/** Price units per 元 (prices are stored in 0.0001 元 per million tokens). */
export declare const PRICE_UNITS_PER_YUAN = 10000;
/** Prices of one model, each in 0.0001 元 per million tokens. */
export interface ModelPrice {
    /** Input tokens served from the cache. */
    readonly inputCacheHit: number;
    /** Input tokens that missed the cache, including tokens written to it. */
    readonly inputCacheMiss: number;
    readonly output: number;
}
/** Quota reset cycles; `total` never resets. */
export type QuotaPeriod = 'day' | 'week' | 'month' | 'year' | 'total';
/** Every quota period, in display order. */
export declare const QUOTA_PERIODS: readonly QuotaPeriod[];
/**
 * Cost of one request.
 * @param usage - token counts the response reported.
 * @param price - the model's price at completion time.
 * @returns cost in micro-yuan, rounded half up.
 */
export declare function requestCostMicros(usage: TokenUsage, price: ModelPrice): number;
/**
 * Parse a yuan amount written with at most 6 decimals.
 * @param text - such as `"100"` or `"0.5"`.
 * @returns micro-yuan.
 * @throws Error when the text is not a non-negative decimal with at most 6 fraction digits.
 */
export declare function parseYuan(text: string): number;
/**
 * Parse a price written in 元 per million tokens with at most 4 decimals.
 * @param text - such as `"2"` or `"0.2"`.
 * @returns price units (0.0001 元 per million tokens).
 */
export declare function parsePrice(text: string): number;
/**
 * Format micro-yuan for people.
 * @param micros - amount in micro-yuan.
 * @returns `¥` amount with 2 decimals, or 4 when the amount is below one fen.
 */
export declare function formatYuan(micros: number): string;
/**
 * Start of the quota period that contains `now`.
 * @param period - the reset cycle; `total` has no start.
 * @param now - the instant, in epoch milliseconds.
 * @param timeZone - IANA time zone whose calendar defines the periods; weeks start on Monday.
 * @returns the period start in epoch milliseconds, or `undefined` for `total`.
 */
export declare function periodStart(period: QuotaPeriod, now: number, timeZone: string): number | undefined;
/**
 * Check that a time zone name is usable.
 * @param timeZone - IANA time zone name.
 * @throws RangeError when the runtime does not know the zone.
 */
export declare function assertTimeZone(timeZone: string): void;
