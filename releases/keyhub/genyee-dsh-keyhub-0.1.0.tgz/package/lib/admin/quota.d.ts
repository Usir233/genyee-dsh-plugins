/** Pre-flight checks of one request: model allowlist, price, concurrency, and two-level money quotas. */
import type { QuotaPeriod } from './money.ts';
import type { KeyhubStore, LedgerAdmission, Quota, QuotaScope } from './store.ts';
/** Why a request is refused, as answered to the employee. */
export interface Refusal {
    /** HTTP status; the DSH adapter maps 402 to a quota failure and retries 429. */
    readonly status: 400 | 402 | 403 | 429;
    readonly type: 'invalid_request_error' | 'permission_error' | 'rate_limit_error' | 'billing_error';
    readonly message: string;
}
/** Where one subject stands against its quota. */
export interface QuotaStanding {
    readonly scope: QuotaScope;
    readonly id: string;
    readonly period: QuotaPeriod;
    /** Quota plus top-ups of the current window, in micro-yuan. */
    readonly allowanceMicros: number;
    /** Spending counted against the window, in micro-yuan. */
    readonly spentMicros: number;
    /** Start of the counted window: the later of the period start and the quota's `since`. */
    readonly countedFrom: number;
    /** Calendar window start, `undefined` for `total`. */
    readonly windowStart: number | undefined;
}
/**
 * Compute where a subject stands against its quota.
 * @param store - the ledger.
 * @param scope - employee or department.
 * @param id - user id or department id.
 * @param quota - the subject's quota.
 * @param now - the instant.
 * @param timeZone - calendar of the periods.
 * @returns allowance and spending of the current window.
 */
export declare function quotaStanding(store: KeyhubStore, scope: QuotaScope, id: string, quota: Quota, now: number, timeZone: string): QuotaStanding;
/** Inputs of one pre-flight check. */
export interface RequestCheck {
    readonly admission: LedgerAdmission;
    /** `model` of the request body, if any. */
    readonly model: string | undefined;
    /** The employee's requests already in flight, excluding this one. */
    readonly inFlight: number;
    readonly now: number;
}
/** Ledger-wide check settings. */
export interface CheckSettings {
    readonly timeZone: string;
    /** Concurrency limit of employees without their own. */
    readonly defaultMaxConcurrency: number;
}
/**
 * Decide whether a request may go to DeepSeek.
 * @param store - the ledger.
 * @param request - who sends what.
 * @param settings - time zone and default limits.
 * @returns the refusal, or `undefined` to forward the request.
 */
export declare function checkRequest(store: KeyhubStore, request: RequestCheck, settings: CheckSettings): Refusal | undefined;
