/** HTTP request handling of the admin relay: admission, rewriting, streaming, interruption, and usage capture. */
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { Admission } from './directory.ts';
import type { Refusal } from './quota.ts';
import type { TokenUsage } from './usage.ts';
/** How one Messages request ended. */
export type RequestOutcome = 'completed' | 'interrupted' | 'failed';
/** One usage record per Messages request that reached DeepSeek. */
export interface UsageRecord {
    /** ISO 8601 completion time. */
    readonly at: string;
    readonly userId: string;
    readonly departmentId: string;
    readonly model: string | undefined;
    /** Upstream HTTP status, or `undefined` when no response arrived. */
    readonly status: number | undefined;
    readonly outcome: RequestOutcome;
    /** Usage the response reported; `undefined` when it reported none. */
    readonly usage: TokenUsage | undefined;
    /** Remote address of the employee connection. */
    readonly clientAddress: string | undefined;
}
/** Facilities the relay handler needs from its host. */
export interface RelayDependencies<A extends Admission> {
    /**
     * Admit one authorization token.
     * @param token - the presented token.
     * @returns the employee and department, or `undefined` when the token is unknown or either is disabled.
     */
    admit(token: string): A | undefined;
    /**
     * Decide whether an admitted Messages request may go to DeepSeek; called right before forwarding.
     * @param admission - the employee and department.
     * @param model - the request's `model`, if any.
     * @param inFlight - the employee's other requests in flight.
     * @returns the refusal, or `undefined` to forward.
     */
    check(admission: A, model: string | undefined, inFlight: number): Refusal | undefined;
    /**
     * Resolve a department key.
     * @param ref - the department's credential reference.
     * @returns the key, or `undefined` when none is configured.
     */
    resolveKey(ref: string): Promise<string | undefined>;
    /** DeepSeek Anthropic-compatible API root. */
    readonly upstreamBaseURL: string;
    readonly upstreamReadTimeoutMs: number;
    readonly maxRequestBytes: number;
    /**
     * Persist one usage record; failures are the callee's to report.
     * @param record - the completed request's record.
     */
    recordUsage(record: UsageRecord, admission: A): void;
    /**
     * Report a contained failure.
     * @param message - diagnostic text without secrets.
     */
    warn(message: string): void;
}
/** A relay request handler with control over in-flight requests. */
export interface Relay<A extends Admission> {
    /**
     * Serve one HTTP request.
     * @param req - the employee request.
     * @param res - its response.
     */
    handle(req: IncomingMessage, res: ServerResponse): void;
    /**
     * Abort every in-flight request whose admission no longer passes.
     * @param stillAdmitted - returns whether a request's employee may continue.
     */
    interrupt(stillAdmitted: (admission: A) => boolean): void;
    /** Abort every in-flight request. */
    closeAll(): void;
}
/**
 * Resolve the Messages API root without duplicating an explicit `/v1` path, as the DSH adapter does.
 * @param baseURL - configured upstream root.
 * @returns the root beneath which `messages` and `files` live.
 */
export declare function apiRoot(baseURL: string): string;
/**
 * Create the relay request handler.
 * @param deps - host facilities and upstream settings.
 * @returns the handler and its in-flight request control.
 */
export declare function createRelay<A extends Admission>(deps: RelayDependencies<A>): Relay<A>;
