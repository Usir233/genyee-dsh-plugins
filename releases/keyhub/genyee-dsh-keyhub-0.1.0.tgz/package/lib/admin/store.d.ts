import type { Admission, Department, Employee } from './directory.ts';
import type { ModelPrice, QuotaPeriod } from './money.ts';
import type { RequestOutcome } from './relay.ts';
import type { TokenUsage } from './usage.ts';
/** Who a quota or top-up applies to. */
export type QuotaScope = 'employee' | 'department';
/** A quota: an amount per period, effective from `since`. */
export interface Quota {
    readonly micros: number;
    readonly period: QuotaPeriod;
    /** When this quota was set; spending before it does not count. */
    readonly since: number;
}
/** A department with its quota. */
export interface DepartmentRecord extends Department {
    readonly quota: Quota | undefined;
}
/** An employee with quota and limits. */
export interface EmployeeRecord extends Employee {
    readonly quota: Quota | undefined;
    /** Models the employee may use; `undefined` allows every priced model. */
    readonly models: readonly string[] | undefined;
    /** Simultaneous requests allowed; `undefined` applies the relay default. */
    readonly maxConcurrency: number | undefined;
}
/** An admitted employee with ledger details. */
export interface LedgerAdmission extends Admission {
    readonly employee: EmployeeRecord;
    readonly department: DepartmentRecord;
}
/** One usage row to append. */
export interface UsageEntry {
    readonly at: number;
    readonly userId: string;
    readonly departmentId: string;
    readonly model: string | undefined;
    readonly status: number | undefined;
    readonly outcome: RequestOutcome;
    readonly usage: TokenUsage | undefined;
    readonly costMicros: number;
    readonly clientAddress: string | undefined;
}
/** Per-subject spending totals over a range. */
export interface SpendingRow {
    readonly id: string;
    readonly requests: number;
    readonly inputTokens: number;
    readonly cacheReadTokens: number;
    readonly cacheWriteTokens: number;
    readonly outputTokens: number;
    readonly costMicros: number;
}
/** The admin ledger in one SQLite file. */
export declare class KeyhubStore {
    private readonly db;
    private constructor();
    /**
     * Open or create the ledger.
     * @param file - SQLite file path.
     * @returns the open store.
     * @throws Error when the file was written by a newer plugin version.
     */
    static open(file: string): KeyhubStore;
    close(): void;
    /**
     * Change counter of writes made through other connections.
     * @returns a value that changes when another connection commits.
     */
    dataVersion(): number;
    /**
     * Admit one authorization token.
     * @param token - the presented token.
     * @returns the employee and department, or `undefined` when the token is unknown or either is disabled.
     */
    admit(token: string): LedgerAdmission | undefined;
    /**
     * Re-read an employee and department for an in-flight request.
     * @param userId - the employee.
     * @returns the current admission, or `undefined` when either is gone or disabled.
     */
    readmit(userId: string): LedgerAdmission | undefined;
    department(id: string): DepartmentRecord | undefined;
    departments(): DepartmentRecord[];
    employee(userId: string): EmployeeRecord | undefined;
    employees(): EmployeeRecord[];
    /**
     * Create or rename a department.
     * @param department - id, display name, key reference, and enabled flag.
     */
    putDepartment(department: Department): void;
    /**
     * Add an employee with a fresh token.
     * @param employee - the new entry's user id, name, and department.
     * @returns the plaintext token, which the ledger does not keep.
     */
    addEmployee(employee: {
        userId: string;
        name: string;
        departmentId: string;
    }): string;
    /**
     * Replace an employee's token; the old token stops working immediately.
     * @param userId - the employee.
     * @returns the new plaintext token.
     */
    resetToken(userId: string): string;
    /**
     * Update employee fields.
     * @param userId - the employee.
     * @param patch - fields to change; `models: null` and `maxConcurrency: null` clear the limit.
     */
    updateEmployee(userId: string, patch: {
        name?: string;
        departmentId?: string;
        enabled?: boolean;
        models?: readonly string[] | null;
        maxConcurrency?: number | null;
    }): void;
    /**
     * Set or clear a quota; spending before `now` stops counting against it.
     * @param scope - employee or department.
     * @param id - user id or department id.
     * @param quota - amount and period, or `undefined` to remove the limit.
     * @param now - when the change takes effect.
     */
    setQuota(scope: QuotaScope, id: string, quota: {
        micros: number;
        period: string;
    } | undefined, now: number): void;
    /**
     * Add a top-up to the current window of a quota.
     * @param scope - employee or department.
     * @param id - user id or department id.
     * @param amountMicros - positive amount added to the allowance.
     * @param windowStart - start of the window the top-up belongs to; `undefined` for a `total` quota.
     * @param note - free text shown to admins.
     * @param now - record time.
     */
    addTopUp(scope: QuotaScope, id: string, amountMicros: number, windowStart: number | undefined, note: string | undefined, now: number): void;
    /**
     * Sum of top-ups for one window.
     * @param scope - employee or department.
     * @param id - user id or department id.
     * @param windowStart - the window start; `undefined` sums `total`-quota top-ups made since `since`.
     * @param since - when the current quota was set.
     * @returns micro-yuan.
     */
    topUps(scope: QuotaScope, id: string, windowStart: number | undefined, since: number): number;
    /**
     * Spending of one employee or department since an instant.
     * @param scope - employee or department.
     * @param id - user id or department id.
     * @param from - inclusive start, epoch milliseconds.
     * @returns micro-yuan.
     */
    spentSince(scope: QuotaScope, id: string, from: number): number;
    /**
     * Record a model price, effective from `now`.
     * @param model - wire model id.
     * @param price - prices in 0.0001 元 per million tokens.
     * @param now - effective time.
     */
    setPrice(model: string, price: ModelPrice, now: number): void;
    /**
     * The price in effect for a model at an instant.
     * @param model - wire model id.
     * @param at - the instant.
     * @returns the price, or `undefined` when none was set by then.
     */
    priceAt(model: string, at: number): ModelPrice | undefined;
    /**
     * Current prices of every priced model.
     * @param now - the instant.
     * @returns model ids with their prices.
     */
    prices(now: number): Array<{
        model: string;
        price: ModelPrice;
    }>;
    /**
     * Append one usage row.
     * @param entry - the completed request.
     */
    recordUsage(entry: UsageEntry): void;
    /**
     * Spending totals grouped by employee or department.
     * @param scope - grouping.
     * @param from - inclusive start, epoch milliseconds.
     * @param to - exclusive end, epoch milliseconds.
     * @returns one row per subject with any request in the range.
     */
    spending(scope: QuotaScope, from: number, to: number): SpendingRow[];
    private requireChange;
}
