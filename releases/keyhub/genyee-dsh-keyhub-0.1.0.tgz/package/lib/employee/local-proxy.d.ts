import type { AccessCode } from '../access-code.ts';
/** A running loopback proxy. */
export interface LocalProxy {
    /** Base URL the DSH route uses, ending in `/anthropic`. */
    readonly baseURL: string;
    /** Per-launch secret the DSH route presents as its `x-api-key`. */
    readonly secret: string;
    /** Stop listening and abort open exchanges. */
    close(): Promise<void>;
}
/** Facilities the proxy needs from its host. */
export interface LocalProxyDependencies {
    /**
     * Read the current access code; called once per request.
     * @returns the decoded access code.
     * @throws Error when the code is missing or malformed; the message is shown to the employee.
     */
    accessCode(): Promise<AccessCode>;
    /** Idle timeout of one relay response, in milliseconds. */
    readonly readTimeoutMs: number;
}
/**
 * Start the loopback proxy on an OS-assigned port.
 * @param deps - access code source and timeouts.
 * @returns the running proxy.
 */
export declare function startLocalProxy(deps: LocalProxyDependencies): Promise<LocalProxy>;
