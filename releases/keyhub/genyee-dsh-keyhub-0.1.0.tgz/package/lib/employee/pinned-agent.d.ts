/** HTTPS agent that trusts exactly one certificate, identified by its SHA-256 fingerprint. */
import type { ClientRequestArgs } from 'node:http';
import { Agent } from 'node:https';
import type { Duplex } from 'node:stream';
import type { AgentOptions } from 'node:https';
/** Raised when the relay presents a certificate other than the pinned one. */
export declare class FingerprintMismatchError extends Error {
    readonly expected: string;
    readonly actual: string;
    constructor(expected: string, actual: string);
}
/**
 * Agent whose connections are handed to requests only after the peer certificate matches the pin,
 * so no request byte reaches an impostor. Chain and host-name validation are replaced by the pin.
 */
export declare class PinnedAgent extends Agent {
    private readonly pin;
    /**
     * @param fingerprint - expected SHA-256 fingerprint, with or without colons.
     * @param options - ordinary agent options such as `keepAlive`.
     */
    constructor(fingerprint: string, options?: AgentOptions);
    createConnection(options: ClientRequestArgs, callback?: (error: Error | null, socket: Duplex) => void): undefined;
}
