/**
 * Genyee key hub: one plugin, two roles.
 * The admin role keeps the company's DeepSeek keys and relays employee requests, binding each to the employee's `user_id`;
 * the employee role registers the `genyee-keyhub` model route, which reaches DeepSeek only through that relay.
 */
import type { Context } from '@deepseek-ai/cordis';
import { Config } from './config.ts';
export { Config } from './config.ts';
export type { AdminConfig, EmployeeConfig } from './config.ts';
export { decodeAccessCode, encodeAccessCode, generateToken } from './access-code.ts';
export type { AccessCode } from './access-code.ts';
export { hashToken } from './admin/directory.ts';
export { PROVIDER } from './employee/index.ts';
export declare const name = "genyee-keyhub";
export declare const inject: string[];
/**
 * Start the configured role.
 * @param ctx - plugin context.
 * @param config - validated settings of this row.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
