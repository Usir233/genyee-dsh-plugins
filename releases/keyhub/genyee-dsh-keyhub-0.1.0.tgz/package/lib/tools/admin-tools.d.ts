/**
 * Create a random DeepSeek `user_id` without personal data.
 * @returns `emp_` followed by 16 base32 characters.
 */
export declare function newUserId(): string;
