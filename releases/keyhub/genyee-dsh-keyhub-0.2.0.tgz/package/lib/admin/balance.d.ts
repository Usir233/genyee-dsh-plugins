/** Periodic DeepSeek account balance queries; all department keys share one account and one balance. */
/** One currency's balance as DeepSeek reports it. */
export interface BalanceInfo {
    readonly currency: string;
    /** Total balance in that currency. */
    readonly total: number;
    readonly granted: number;
    readonly toppedUp: number;
}
/** The latest balance query. */
export type BalanceReading = {
    readonly state: 'unknown';
} | {
    readonly state: 'ok';
    readonly at: number;
    readonly available: boolean;
    readonly balances: readonly BalanceInfo[];
    readonly low: boolean;
} | {
    readonly state: 'failed';
    readonly at: number;
    readonly message: string;
};
/** Facilities of one balance monitor. */
export interface BalanceMonitorOptions {
    /** DeepSeek balance endpoint. */
    readonly url: string;
    /**
     * Resolve the key to query with.
     * @returns an enabled department's key, or `undefined` when no department has one.
     */
    key(): Promise<string | undefined>;
    /** Balance in CNY below which the reading is low. */
    readonly lowBalanceYuan: number;
    /**
     * Report a low or failed reading.
     * @param message - diagnostic text without secrets.
     */
    warn(message: string): void;
    readonly fetch?: typeof fetch;
}
/**
 * Parse a `GET /user/balance` answer.
 * @param body - the JSON answer.
 * @returns availability and per-currency balances.
 * @throws Error when the answer lacks the documented fields.
 */
export declare function parseBalance(body: unknown): {
    available: boolean;
    balances: BalanceInfo[];
};
/** Queries the account balance on demand and keeps the latest reading. */
export declare class BalanceMonitor {
    private readonly options;
    private reading;
    private running;
    constructor(options: BalanceMonitorOptions);
    /** @returns the latest reading. */
    latest(): BalanceReading;
    /**
     * Query the balance now; concurrent calls share one query.
     * @returns the new reading.
     */
    refresh(): Promise<BalanceReading>;
    private query;
}
