/** Admin role: serve the relay over HTTPS (or explicitly plain HTTP), enforce the ledger, and serve the management page. */
import type { Context } from '@deepseek-ai/cordis';
import type { AdminConfig } from '../config.ts';
/**
 * Reject wildcard, non-literal, and non-local listen addresses.
 * @param host - the configured listen address.
 * @param localAddresses - addresses of this machine's interfaces.
 * @throws Error when `host` is not one concrete IP literal of a local interface.
 */
export declare function assertConcreteHost(host: string, localAddresses?: readonly string[]): void;
/**
 * Start the admin role.
 * @param ctx - the plugin context owning the ledger, the listener, the ledger watch, the balance poll, and the management RPC.
 * @param config - admin settings.
 */
export declare function applyAdmin(ctx: Context, config: AdminConfig): Promise<void>;
