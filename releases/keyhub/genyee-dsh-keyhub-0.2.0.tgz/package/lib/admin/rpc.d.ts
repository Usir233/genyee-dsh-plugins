/**
 * Management-page commands of the admin role, served on {@link ADMIN_ROUTE}. Only the owner of the admin's DSH reaches
 * the route (see `src/rpc-route.ts`); employees reach the relay, never this route.
 */
import type { RpcHandler } from '../rpc-route.ts';
import type { BalanceMonitor, BalanceReading } from './balance.ts';
import type { LedgerOverview } from './ledger-ops.ts';
import type { KeyhubStore } from './store.ts';
/** Connection API route of the management page. */
export declare const ADMIN_ROUTE = "/api/genyee-keyhub/admin";
/** Relay facts shown on the service tab. */
export interface ServiceInfo {
    /** Origin employees reach, such as `https://10.0.0.8:8443`. */
    readonly relayURL: string;
    /** Certificate fingerprint carried in access codes; absent for plain HTTP. */
    readonly fingerprint: string | undefined;
    readonly upstreamBaseURL: string;
    readonly timeZone: string;
    readonly defaultMaxConcurrency: number;
    readonly lowBalanceYuan: number;
    readonly version: string;
}
/** Facilities of the management RPC. */
export interface AdminRpcDependencies {
    readonly store: KeyhubStore;
    readonly service: ServiceInfo;
    readonly balance: BalanceMonitor;
    /**
     * Whether a department key reference resolves to a value.
     * @param ref - credential reference name.
     * @returns configured state.
     */
    keyConfigured(ref: string): Promise<boolean>;
    /**
     * Store a department key in the admin's credentials.
     * @param ref - credential reference name.
     * @param key - the DeepSeek API key.
     */
    storeKey(ref: string, key: string): Promise<void>;
    /**
     * Interrupt in-flight requests whose employee lost admission after a ledger write.
     */
    ledgerChanged(): void;
    /**
     * Encode an access code for a fresh token.
     * @param token - the employee's new authorization token.
     * @returns the pasteable access code.
     */
    accessCode(token: string): string;
    readonly now?: () => number;
}
/** Everything the management page loads at once. */
export interface ManagementState extends LedgerOverview {
    /** Department id → whether its key reference resolves. */
    readonly keyConfigured: Readonly<Record<string, boolean>>;
    readonly service: ServiceInfo;
    readonly balance: BalanceReading;
}
/**
 * Create the management command handler.
 * @param deps - the ledger and admin facilities.
 * @returns a handler of one decoded command.
 */
export declare function createAdminRpc(deps: AdminRpcDependencies): RpcHandler;
