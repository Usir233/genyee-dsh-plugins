/** Token counts of one completed request, in Anthropic Messages terms. */
export interface TokenUsage {
    /** Input tokens that missed the cache and were not written to it. */
    inputTokens: number;
    /** Input tokens served from the cache (`cache_read_input_tokens`). */
    cacheReadTokens: number;
    /** Input tokens written to the cache (`cache_creation_input_tokens`). */
    cacheWriteTokens: number;
    outputTokens: number;
}
/** Usage observed in one response. */
export interface ObservedUsage {
    readonly usage: TokenUsage;
    /**
     * Whether `outputTokens` is an estimate: the stream ended after `message_start` but before the final
     * `message_delta`, typically because the employee disconnected while DeepSeek was still generating.
     */
    readonly estimated: boolean;
}
/**
 * UTF-8 bytes of streamed output per token assumed when the final usage is missing.
 * A measured DeepSeek Chinese answer billed one output token per 4.8 bytes; English text runs denser,
 * so this figure slightly overestimates Chinese output and roughly matches English.
 */
export declare const ESTIMATE_BYTES_PER_OUTPUT_TOKEN = 4;
/** Incremental observer of one response body. */
export interface UsageTap {
    /**
     * Observe the next forwarded chunk.
     * @param chunk - bytes exactly as forwarded to the employee.
     */
    push(chunk: Buffer): void;
    /**
     * Finish observation.
     * @returns the usage the response reported or implied, or `undefined` when it reported none.
     */
    finish(): ObservedUsage | undefined;
}
/**
 * Observe an SSE Messages stream (`message_start` and `message_delta` events).
 * @returns a tap fed with the raw stream bytes.
 */
export declare function streamUsageTap(): UsageTap;
/**
 * Observe a non-streaming JSON Messages response.
 * @param limitBytes - bytes retained for parsing; a larger body reports no usage.
 * @returns a tap fed with the raw response bytes.
 */
export declare function jsonUsageTap(limitBytes: number): UsageTap;
