/** Plugin configuration: one row selects the admin or employee role and that role's settings. */
import z from '@deepseek-ai/schemastery';
/** Settings of the admin role, which holds the company keys and relays employee requests. */
export interface AdminConfig {
    role: 'admin';
    /** Concrete local interface address the relay listens on; wildcard addresses are rejected. */
    listenHost: string;
    /** TCP port of the relay listener. */
    listenPort: number;
    /** PEM certificate file served by the relay; required unless `insecureHttp` is set. */
    tlsCertFile?: string;
    /** PEM private key file matching `tlsCertFile`. */
    tlsKeyFile?: string;
    /** Serve plain HTTP; authorization codes then cross the network unencrypted. */
    insecureHttp: boolean;
    /** SQLite ledger of departments, employees, prices, quotas, and usage; created when missing. */
    ledgerFile: string;
    /** IANA time zone whose calendar defines quota days, weeks (from Monday), months, and years. */
    timeZone: string;
    /** Simultaneous requests allowed to an employee without a limit of their own. */
    defaultMaxConcurrency: number;
    /** DeepSeek Anthropic-compatible API root the relay forwards to. */
    upstreamBaseURL: string;
    /** Idle read timeout of one upstream response; DeepSeek keeps a queued request alive for up to 10 minutes. */
    upstreamReadTimeoutMs: number;
    /** Largest accepted request body, in bytes. */
    maxRequestBytes: number;
    /** DeepSeek account balance endpoint, queried with an enabled department key. */
    balanceURL: string;
    /** Minutes between account balance queries; `0` turns them off. */
    balancePollMinutes: number;
    /** Balance in 元 below which the management page and the log warn. */
    lowBalanceYuan: number;
}
/** Settings of the employee role, which reaches the company models only through the admin relay. */
export interface EmployeeConfig {
    role: 'employee';
    /** Credential reference holding the access code the admin issued to this employee. */
    accessCodeRef: string;
    /** Idle read timeout of one relay response; keep it above the admin's `upstreamReadTimeoutMs`. */
    relayReadTimeoutMs: number;
}
/** Settings of one plugin row. */
export type Config = AdminConfig | EmployeeConfig;
export declare const Config: z<Config>;
