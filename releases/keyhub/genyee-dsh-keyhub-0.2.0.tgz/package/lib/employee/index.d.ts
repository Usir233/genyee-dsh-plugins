/** Employee role: register the `genyee-keyhub` DeepSeek route, served through the loopback proxy to the admin relay. */
import type { Context } from '@deepseek-ai/cordis';
import type { EmployeeConfig } from '../config.ts';
/** Provider route id employees select. */
export declare const PROVIDER = "genyee-keyhub";
/**
 * Start the employee role.
 * @param ctx - the plugin context owning the proxy, the route, and the settings RPC.
 * @param config - employee settings.
 */
export declare function applyEmployee(ctx: Context, config: EmployeeConfig): Promise<void>;
