import type { RpcHandler } from '../rpc-route.ts';
/** Connection API route of the employee settings section. */
export declare const EMPLOYEE_ROUTE = "/api/genyee-keyhub/employee";
/** What the settings section shows. */
export interface EmployeeConnection {
    readonly accessCodeRef: string;
    /** Whether an access code is stored. */
    readonly configured: boolean;
    /** Relay origin from the stored access code. */
    readonly relayURL: string | undefined;
    /** Whether the relay answered and admitted the stored code. */
    readonly connected: boolean;
    /** The relay's status body when connected. */
    readonly status: unknown;
    /** Why the relay is not usable, written for the employee. */
    readonly message: string | undefined;
}
/** Facilities of the settings RPC. */
export interface EmployeeRpcDependencies {
    readonly accessCodeRef: string;
    /**
     * Read the stored access code text.
     * @returns the text, or `undefined` when none is stored.
     */
    readRaw(): Promise<string | undefined>;
    /**
     * Store a validated access code.
     * @param code - the access code text.
     */
    save(code: string): Promise<void>;
    /** Remove the stored access code. */
    clear(): Promise<void>;
    /**
     * Query the relay status with the stored code.
     * @returns the status body, or the relay's refusal message.
     * @throws Error when the relay cannot be reached.
     */
    relayStatus(): Promise<{
        ok: true;
        status: unknown;
    } | {
        ok: false;
        message: string;
    }>;
}
/**
 * Create the settings command handler.
 * @param deps - credential access and the relay status query.
 * @returns a handler of one decoded command.
 */
export declare function createEmployeeRpc(deps: EmployeeRpcDependencies): RpcHandler;
