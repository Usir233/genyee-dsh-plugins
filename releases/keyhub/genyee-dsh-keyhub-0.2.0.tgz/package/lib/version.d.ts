/** The `version` of `@genyee/dsh-keyhub`'s package.json; `src/` and `lib/` both sit one level below it. */
export declare const PLUGIN_VERSION: string;
