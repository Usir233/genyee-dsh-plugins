/** Relay origin and certificate fingerprint, without an employee token. */
export interface RelayEndpoint {
    /** Relay origin, `https://host:port` (or `http://` for a relay serving plain HTTP). */
    readonly relayURL: string;
    /** Lowercase hex SHA-256 fingerprint of the relay certificate; absent for plain HTTP. */
    readonly fingerprint: string | undefined;
}
/** Decoded access code. */
export interface AccessCode extends RelayEndpoint {
    /** The employee's authorization token. */
    readonly token: string;
}
/**
 * Normalize a certificate fingerprint written with or without colons, in either case.
 * @param value - fingerprint text, such as Node's `fingerprint256`.
 * @returns lowercase hex without separators.
 */
export declare function normalizeFingerprint(value: string): string;
/**
 * Generate a new authorization token.
 * @returns `gk_` followed by 256 random bits in base64url.
 */
export declare function generateToken(): string;
/**
 * Encode an access code.
 * @param code - relay address, fingerprint, and token.
 * @returns the pasteable access code.
 */
export declare function encodeAccessCode(code: AccessCode): string;
/**
 * Decode and validate an access code.
 * @param text - the pasted access code; surrounding whitespace is ignored.
 * @returns the decoded fields.
 * @throws Error when the code is malformed, names a non-HTTP(S) origin, or pairs HTTPS without a fingerprint.
 */
export declare function decodeAccessCode(text: string): AccessCode;
/**
 * Whether a pasted string is a relay connection update code (`gkhu1.`).
 * @param text - pasted text.
 * @returns `true` when it starts with `gkhu1.`.
 */
export declare function isRelayUpdate(text: string): boolean;
/**
 * Encode a relay connection update code carrying only the relay origin and certificate fingerprint.
 * @param endpoint - relay address and optional fingerprint.
 * @returns the pasteable update code (`gkhu1.…`).
 */
export declare function encodeRelayUpdate(endpoint: RelayEndpoint): string;
/**
 * Decode and validate a relay connection update code (`gkhu1.…`).
 * @param text - the pasted update code; surrounding whitespace is ignored.
 * @returns the new relay origin and certificate fingerprint.
 */
export declare function decodeRelayUpdate(text: string): RelayEndpoint;
/**
 * Replace the relay origin and certificate fingerprint of an existing employee access code while keeping its token.
 * @param existingAccessCode - the employee's stored `gkh1.…` access code.
 * @param updateText - the admin's `gkhu1.…` relay update code.
 * @returns the updated `gkh1.…` access code.
 */
export declare function applyRelayUpdate(existingAccessCode: string, updateText: string): string;
