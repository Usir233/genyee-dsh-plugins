import type { QuotaPeriod } from './money.ts';
import type { QuotaStanding } from './quota.ts';
import type { DepartmentRecord, EmployeeRecord, KeyhubStore, LedgerAdmission, Quota, QuotaScope, UsageFilter } from './store.ts';
/** Reference prices (元 per million tokens) for common DeepSeek models. */
export declare const DEFAULT_MODEL_PRICES: ReadonlyArray<{
    readonly model: string;
    readonly hit: string;
    readonly miss: string;
    readonly output: string;
}>;
/**
 * Fill reference prices for common DeepSeek models that have no price yet.
 * @param store - the ledger.
 * @param now - effective time.
 * @returns number of models whose price was added.
 */
export declare function applyDefaultPrices(store: KeyhubStore, now: number): number;
/**
 * Create a random DeepSeek `user_id` without personal data.
 * @returns `emp_` followed by 16 base32 characters.
 */
export declare function newUserId(): string;
/**
 * SHA-256 fingerprint of a PEM certificate, as access codes carry it.
 * @param pem - the relay certificate.
 * @returns lowercase hex without separators.
 */
export declare function certificateFingerprint(pem: string | Buffer): string;
/**
 * Where a subject stands against its quota, on the ledger's calendar.
 * @param store - the ledger.
 * @param scope - employee or department.
 * @param id - user id or department id.
 * @param quota - the subject's quota.
 * @param now - the instant.
 * @returns allowance and spending of the current window.
 */
export declare function standingOf(store: KeyhubStore, scope: QuotaScope, id: string, quota: Quota, now: number): QuotaStanding;
/**
 * Add a top-up to the current window of a subject's quota, on the ledger's calendar.
 * @param store - the ledger.
 * @param scope - employee or department.
 * @param id - user id or department id.
 * @param amountMicros - positive amount.
 * @param note - free text shown to admins.
 * @param now - record time.
 * @throws Error when the subject has no quota.
 */
export declare function topUp(store: KeyhubStore, scope: QuotaScope, id: string, amountMicros: number, note: string | undefined, now: number): void;
/** A quota with its current window, in micro-yuan. */
export interface QuotaView {
    readonly period: QuotaPeriod;
    /** The quota without top-ups. */
    readonly quotaMicros: number;
    /** Quota plus top-ups of the current window. */
    readonly allowanceMicros: number;
    readonly spentMicros: number;
    /** Allowance left, never below zero. */
    readonly remainingMicros: number;
}
/**
 * Project a quota for display.
 * @param store - the ledger.
 * @param scope - employee or department.
 * @param id - user id or department id.
 * @param quota - the subject's quota, if any.
 * @param now - the instant.
 * @returns the view, or `undefined` when the subject has no quota.
 */
export declare function quotaView(store: KeyhubStore, scope: QuotaScope, id: string, quota: Quota | undefined, now: number): QuotaView | undefined;
/** A department as the management page lists it. */
export interface DepartmentView extends Omit<DepartmentRecord, 'quota'> {
    readonly quota: QuotaView | undefined;
    readonly monthSpentMicros: number;
    readonly employees: number;
}
/** An employee as the management page lists it. */
export interface EmployeeView extends Omit<EmployeeRecord, 'quota' | 'tokenSha256'> {
    readonly quota: QuotaView | undefined;
    readonly monthSpentMicros: number;
    readonly monthRequests: number;
    readonly lastClientAddress: string | undefined;
    readonly recentClientAddresses: readonly string[];
}
/** One current model price, in 元 per million tokens. */
export interface PriceView {
    readonly model: string;
    readonly inputCacheHit: number;
    readonly inputCacheMiss: number;
    readonly output: number;
}
/** Everything the management page shows about the ledger. */
export interface LedgerOverview {
    readonly timeZone: string;
    readonly departments: readonly DepartmentView[];
    readonly employees: readonly EmployeeView[];
    readonly prices: readonly PriceView[];
}
/**
 * Collect the ledger state the management page shows.
 * @param store - the ledger.
 * @param now - the instant.
 * @returns departments, employees, and prices with their quota standings and this month's spending.
 */
export declare function overview(store: KeyhubStore, now: number): LedgerOverview;
/** What the relay answers an employee on `GET /keyhub/v1/status`. */
export interface EmployeeStatus {
    readonly employee: string;
    readonly userId: string;
    readonly department: string;
    /** Models the employee may use now: allowed and priced. */
    readonly models: readonly string[];
    readonly maxConcurrency: number;
    readonly quota: {
        readonly employee: QuotaView | undefined;
        readonly department: QuotaView | undefined;
    };
    /** Epoch milliseconds when this employee's token expires, if set. */
    readonly expiresAt?: number;
    /** Version of the plugin serving the relay. */
    readonly relayVersion: string;
}
/**
 * Describe an admitted employee's standing.
 * @param store - the ledger.
 * @param admission - the employee and department.
 * @param now - the instant.
 * @param defaultMaxConcurrency - limit of employees without their own.
 * @param relayVersion - the serving plugin version.
 * @returns the status body.
 */
export declare function employeeStatus(store: KeyhubStore, admission: LedgerAdmission, now: number, defaultMaxConcurrency: number, relayVersion: string): EmployeeStatus;
/**
 * Export usage rows as CSV for spreadsheets: UTF-8 with a byte order mark, times on the ledger's calendar.
 * @param store - the ledger.
 * @param filter - time range and optional employee or department.
 * @returns the CSV text.
 */
export declare function usageCsv(store: KeyhubStore, filter: UsageFilter): string;
/**
 * Summarize a quota for a terminal report.
 * @param view - the quota view, if any.
 * @returns text such as `month: 已用 ¥1.00 / ¥100.00`.
 */
export declare function describeQuota(view: QuotaView | undefined): string;
