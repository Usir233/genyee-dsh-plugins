import type { Relay } from './relay.ts';
import type { KeyhubStore, LedgerAdmission } from './store.ts';
/** Settings and host facilities of a ledger relay. */
export interface LedgerRelayOptions {
    readonly timeZone: string;
    readonly defaultMaxConcurrency: number;
    readonly upstreamBaseURL: string;
    readonly upstreamReadTimeoutMs: number;
    readonly maxRequestBytes: number;
    /**
     * Resolve a department key.
     * @param ref - credential reference name.
     * @returns the key, or `undefined` when none is configured.
     */
    resolveKey(ref: string): Promise<string | undefined>;
    /**
     * Report a contained failure.
     * @param message - diagnostic text without secrets.
     */
    warn(message: string): void;
}
/** A ledger relay with its in-flight re-check. */
export interface LedgerRelay {
    readonly relay: Relay<LedgerAdmission>;
    /** Abort in-flight requests whose employee was disabled, expired, got a new token, or changed department. */
    recheck(now?: number): void;
}
/**
 * Create the relay over a ledger.
 * @param ledger - the open ledger; the caller owns closing it after the relay stops.
 * @param options - settings and host facilities.
 * @returns the relay and its re-check.
 */
export declare function createLedgerRelay(ledger: KeyhubStore, options: LedgerRelayOptions): LedgerRelay;
