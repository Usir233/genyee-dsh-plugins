/** Pre-flight checks of one request: model allowlist, price, concurrency, and two-level money quotas. */
import type { ModelPrice, QuotaPeriod } from './money.ts';
import type { KeyhubStore, LedgerAdmission, Quota, QuotaScope } from './store.ts';
/**
 * Why a request is refused, as answered to the employee.
 * The DSH client replaces the message of 401, 402, and 403 answers with its own generic text ("API key invalid",
 * "quota exhausted"), so refusals the employee must read are 400 `invalid_request_error`, which DSH shows verbatim
 * and does not retry; `code` names the reason for other clients. Only the concurrency limit is 429, which DSH retries.
 */
export interface Refusal {
    readonly status: 400 | 429;
    readonly type: 'invalid_request_error' | 'rate_limit_error';
    /** Machine-readable reason, such as `keyhub_quota_exhausted`. */
    readonly code: string;
    readonly message: string;
}
/** Where one subject stands against its quota. */
export interface QuotaStanding {
    readonly scope: QuotaScope;
    readonly id: string;
    readonly period: QuotaPeriod;
    /** Quota plus top-ups of the current window, in micro-yuan. */
    readonly allowanceMicros: number;
    /** Spending counted against the window, in micro-yuan. */
    readonly spentMicros: number;
    /** Start of the counted window: the later of the period start and the quota's `since`. */
    readonly countedFrom: number;
    /** Calendar window start, `undefined` for `total`. */
    readonly windowStart: number | undefined;
}
/**
 * Compute where a subject stands against its quota.
 * @param store - the ledger.
 * @param scope - employee or department.
 * @param id - user id or department id.
 * @param quota - the subject's quota.
 * @param now - the instant.
 * @param timeZone - calendar of the periods.
 * @returns allowance and spending of the current window.
 */
export declare function quotaStanding(store: KeyhubStore, scope: QuotaScope, id: string, quota: Quota, now: number, timeZone: string): QuotaStanding;
/** Requests already in flight that a new request competes with. */
export interface PendingRequests {
    /** The employee's Messages requests in flight. */
    readonly count: number;
    /** Cost reserved by the employee's requests in flight, in micro-yuan. */
    readonly employeeMicros: number;
    /** Cost reserved by the department's requests in flight, in micro-yuan. */
    readonly departmentMicros: number;
}
/** Inputs of one pre-flight check. */
export interface RequestCheck {
    readonly admission: LedgerAdmission;
    /** `model` of the request body, if any. */
    readonly model: string | undefined;
    /** `max_tokens` of the request body, if any. */
    readonly maxTokens: number | undefined;
    /** Byte length of the forwarded request body. */
    readonly bodyBytes: number;
    readonly pending: PendingRequests;
    readonly now: number;
}
/** Outcome of a pre-flight check. */
export type CheckResult = {
    readonly ok: true; /** Cost to reserve while the request runs, in micro-yuan. */
    readonly reserveMicros: number;
} | {
    readonly ok: false;
    readonly refusal: Refusal;
};
/**
 * Cost to reserve for a request in flight, before its usage is known.
 * Input is priced as cache misses and output at its `max_tokens`, so the reservation bounds the actual cost from above.
 * @param price - the model's current price.
 * @param bodyBytes - byte length of the request body.
 * @param maxTokens - the request's `max_tokens`, if any.
 * @returns micro-yuan.
 */
export declare function reservationMicros(price: ModelPrice, bodyBytes: number, maxTokens: number | undefined): number;
/** Ledger-wide check settings. */
export interface CheckSettings {
    readonly timeZone: string;
    /** Concurrency limit of employees without their own. */
    readonly defaultMaxConcurrency: number;
}
/**
 * Refuse an employee whose authorization token has passed its expiration time.
 * @param admission - the employee and department.
 * @param now - the instant.
 * @returns the refusal, or `undefined` when the token has not expired.
 */
export declare function checkExpiry(admission: LedgerAdmission, now: number): Refusal | undefined;
/**
 * Check both quota levels of an admitted employee.
 * Spending plus the reservations of requests already in flight must stay below each allowance; the new request's own
 * cost is not counted, so the last admitted request may overrun by at most its own cost.
 * @param store - the ledger.
 * @param admission - the employee and department.
 * @param pending - reservations of requests in flight.
 * @param now - the instant.
 * @param timeZone - calendar of the periods.
 * @returns the refusal, or `undefined` when both levels have room.
 */
export declare function checkQuotas(store: KeyhubStore, admission: LedgerAdmission, pending: Pick<PendingRequests, 'employeeMicros' | 'departmentMicros'>, now: number, timeZone: string): Refusal | undefined;
/**
 * Decide whether a Messages request may go to DeepSeek.
 * @param store - the ledger.
 * @param request - who sends what, and what is already in flight.
 * @param settings - time zone and default limits.
 * @returns the reservation to hold while the request runs, or the refusal.
 */
export declare function checkRequest(store: KeyhubStore, request: RequestCheck, settings: CheckSettings): CheckResult;
