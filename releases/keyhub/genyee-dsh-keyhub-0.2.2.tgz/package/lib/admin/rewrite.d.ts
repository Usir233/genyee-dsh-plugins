/** Request rewriting applied by the admin relay before a request leaves for DeepSeek. */
import type { IncomingHttpHeaders, OutgoingHttpHeaders } from 'node:http';
/** Outcome of rewriting one Messages request body. */
export type BodyRewrite = {
    readonly ok: true;
    readonly body: Buffer;
    readonly model: string | undefined;
    readonly maxTokens: number | undefined;
    readonly fileIds: readonly string[];
} | {
    readonly ok: false;
    readonly reason: string;
};
/**
 * Bind a Messages request to one employee.
 * Overwrites `metadata.user_id`, keeps the other `metadata` fields, and removes every DSH body extension field.
 * @param raw - the request body the employee sent.
 * @param userId - the employee's DeepSeek `user_id`.
 * @returns the rewritten JSON body with its `model`, `max_tokens`, and referenced `fileIds`, or the reason the body is not a JSON object.
 */
export declare function rewriteMessagesBody(raw: Buffer, userId: string): BodyRewrite;
/**
 * Build upstream request headers.
 * @param incoming - headers the employee sent.
 * @param apiKey - the department's DeepSeek API key.
 * @param contentLength - byte length of the forwarded body, or `undefined` to stream it.
 * @returns headers with the employee credential replaced by `apiKey` and an identity content coding.
 */
export declare function upstreamHeaders(incoming: IncomingHttpHeaders, apiKey: string, contentLength: number | undefined): OutgoingHttpHeaders;
/**
 * Build the headers answered to the employee.
 * @param upstream - headers DeepSeek answered with.
 * @returns the headers without hop-by-hop and length fields.
 */
export declare function downstreamHeaders(upstream: IncomingHttpHeaders): OutgoingHttpHeaders;
