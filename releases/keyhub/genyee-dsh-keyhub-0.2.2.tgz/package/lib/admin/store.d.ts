import type { Admission, Department, Employee } from './directory.ts';
import type { ModelPrice, QuotaPeriod } from './money.ts';
import type { RequestOutcome } from './relay.ts';
import type { TokenUsage } from './usage.ts';
/** Time zone recorded before any admin started the relay on this ledger. */
export declare const DEFAULT_TIME_ZONE = "Asia/Shanghai";
/** Who a quota or top-up applies to. */
export type QuotaScope = 'employee' | 'department';
/** A quota: an amount per period, effective from `since`. */
export interface Quota {
    readonly micros: number;
    readonly period: QuotaPeriod;
    /** When this quota was set; spending before it does not count. */
    readonly since: number;
}
/** A department with its quota. */
export interface DepartmentRecord extends Department {
    readonly quota: Quota | undefined;
}
/** An employee with quota and limits. */
export interface EmployeeRecord extends Employee {
    readonly quota: Quota | undefined;
    /** Models the employee may use; `undefined` allows every priced model. */
    readonly models: readonly string[] | undefined;
    /** Simultaneous requests allowed; `undefined` applies the relay default. */
    readonly maxConcurrency: number | undefined;
    /** Epoch milliseconds when this employee's token expires; `undefined` when it does not expire. */
    readonly expiresAt: number | undefined;
}
/** An admitted employee with ledger details. */
export interface LedgerAdmission extends Admission {
    readonly employee: EmployeeRecord;
    readonly department: DepartmentRecord;
}
/** One usage row to append. */
export interface UsageEntry {
    readonly at: number;
    readonly userId: string;
    readonly departmentId: string;
    readonly model: string | undefined;
    readonly status: number | undefined;
    readonly outcome: RequestOutcome;
    readonly usage: TokenUsage | undefined;
    /** Whether output tokens were estimated because the stream ended before its final usage. */
    readonly estimated: boolean;
    readonly costMicros: number;
    readonly clientAddress: string | undefined;
}
/** One usage row as stored, for reports and export. */
export interface UsageRow {
    readonly at: number;
    readonly userId: string;
    readonly departmentId: string;
    readonly model: string | undefined;
    readonly status: number | undefined;
    readonly outcome: string;
    readonly inputTokens: number;
    readonly cacheReadTokens: number;
    readonly cacheWriteTokens: number;
    readonly outputTokens: number;
    readonly estimated: boolean;
    readonly costMicros: number;
    readonly clientAddress: string | undefined;
}
/** Filter of {@link KeyhubStore.usageRows}. */
export interface UsageFilter {
    /** Inclusive start, epoch milliseconds. */
    readonly from: number;
    /** Exclusive end, epoch milliseconds. */
    readonly to: number;
    readonly userId?: string;
    readonly departmentId?: string;
}
/** Per-subject spending totals over a range. */
export interface SpendingRow {
    readonly id: string;
    readonly requests: number;
    readonly inputTokens: number;
    readonly cacheReadTokens: number;
    readonly cacheWriteTokens: number;
    readonly outputTokens: number;
    readonly costMicros: number;
}
/** The admin ledger in one SQLite file. */
export declare class KeyhubStore {
    private readonly db;
    private constructor();
    /**
     * Open or create the ledger.
     * @param file - SQLite file path.
     * @returns the open store.
     * @throws Error when the file was written by a newer plugin version.
     */
    static open(file: string): KeyhubStore;
    /**
     * Bring the schema to {@link SCHEMA_VERSION} in one write transaction.
     * The generation is re-read under the write lock, so a concurrent opener that migrated first is not migrated again.
     */
    private static migrate;
    close(): void;
    /**
     * The calendar of quota periods, written by the admin relay at startup.
     * @returns the IANA time zone, {@link DEFAULT_TIME_ZONE} before the relay first ran.
     */
    timeZone(): string;
    /**
     * Record the calendar of quota periods; admin tools and the management page read it from here.
     * @param timeZone - IANA time zone the relay uses.
     */
    setTimeZone(timeZone: string): void;
    /**
     * Change counter of writes made through other connections.
     * @returns a value that changes when another connection commits.
     */
    dataVersion(): number;
    /**
     * Admit one authorization token.
     * @param token - the presented token.
     * @returns the employee and department, or `undefined` when the token is unknown or either is disabled.
     */
    admit(token: string): LedgerAdmission | undefined;
    /**
     * Re-read an employee and department for an in-flight request.
     * @param userId - the employee.
     * @param now - the instant, used to check token expiration.
     * @returns the current admission, or `undefined` when either is gone, disabled, or expired.
     */
    readmit(userId: string, now?: number): LedgerAdmission | undefined;
    department(id: string): DepartmentRecord | undefined;
    departments(): DepartmentRecord[];
    employee(userId: string): EmployeeRecord | undefined;
    employees(): EmployeeRecord[];
    /**
     * Create or rename a department.
     * @param department - id, display name, key reference, and enabled flag.
     */
    putDepartment(department: Department): void;
    /**
     * Add an employee with a fresh token.
     * @param employee - the new entry's user id, name, department, and optional expiration instant.
     * @returns the plaintext token, which the ledger does not keep.
     */
    addEmployee(employee: {
        userId: string;
        name: string;
        departmentId: string;
        expiresAt?: number;
    }): string;
    /**
     * Replace an employee's token; the old token stops working immediately.
     * @param userId - the employee.
     * @returns the new plaintext token.
     */
    resetToken(userId: string): string;
    /**
     * Update employee fields.
     * @param userId - the employee.
     * @param patch - fields to change; `models: null`, `maxConcurrency: null`, and `expiresAt: null` clear the limit.
     */
    updateEmployee(userId: string, patch: {
        name?: string;
        departmentId?: string;
        enabled?: boolean;
        models?: readonly string[] | null;
        maxConcurrency?: number | null;
        expiresAt?: number | null;
    }): void;
    /**
     * Set or clear a quota.
     * Changing only the amount keeps the counting start, so spending and top-ups of the current window still count;
     * setting a first quota or changing the period counts from `now`.
     * @param scope - employee or department.
     * @param id - user id or department id.
     * @param quota - amount and period, or `undefined` to remove the limit.
     * @param now - when the change takes effect.
     */
    setQuota(scope: QuotaScope, id: string, quota: {
        micros: number;
        period: string;
    } | undefined, now: number): void;
    /**
     * Add a top-up to the current window of a quota.
     * @param scope - employee or department.
     * @param id - user id or department id.
     * @param amountMicros - positive amount added to the allowance.
     * @param windowStart - start of the window the top-up belongs to; `undefined` for a `total` quota.
     * @param note - free text shown to admins.
     * @param now - record time.
     */
    addTopUp(scope: QuotaScope, id: string, amountMicros: number, windowStart: number | undefined, note: string | undefined, now: number): void;
    /**
     * Sum of top-ups for one window.
     * @param scope - employee or department.
     * @param id - user id or department id.
     * @param windowStart - the window start; `undefined` sums `total`-quota top-ups made since `since`.
     * @param since - when the current quota was set.
     * @returns micro-yuan.
     */
    topUps(scope: QuotaScope, id: string, windowStart: number | undefined, since: number): number;
    /**
     * Spending of one employee or department since an instant.
     * @param scope - employee or department.
     * @param id - user id or department id.
     * @param from - inclusive start, epoch milliseconds.
     * @returns micro-yuan.
     */
    spentSince(scope: QuotaScope, id: string, from: number): number;
    /**
     * Record a model price, effective from `now`.
     * @param model - wire model id.
     * @param price - prices in 0.0001 元 per million tokens.
     * @param now - effective time.
     */
    setPrice(model: string, price: ModelPrice, now: number): void;
    /**
     * Remove every price of a model; recorded usage keeps the cost computed when it completed.
     * @param model - wire model id.
     * @throws Error when the model has no price.
     */
    removePrice(model: string): void;
    /**
     * The price in effect for a model at an instant.
     * @param model - wire model id.
     * @param at - the instant.
     * @returns the price, or `undefined` when none was set by then.
     */
    priceAt(model: string, at: number): ModelPrice | undefined;
    /**
     * Current prices of every priced model.
     * @param now - the instant.
     * @returns model ids with their prices.
     */
    prices(now: number): Array<{
        model: string;
        price: ModelPrice;
    }>;
    /**
     * Append one usage row.
     * @param entry - the completed request.
     */
    recordUsage(entry: UsageEntry): void;
    /**
     * Usage rows in a range, oldest first.
     * @param filter - time range and optional employee or department.
     * @returns the matching rows.
     */
    usageRows(filter: UsageFilter): UsageRow[];
    /**
     * Record the employee who uploaded a file through the relay.
     * @param fileId - DeepSeek file id.
     * @param userId - the uploading employee.
     * @param departmentId - the department whose key holds the file.
     * @param now - upload time.
     */
    recordFile(fileId: string, userId: string, departmentId: string, now: number): void;
    /**
     * The employee who uploaded a file.
     * @param fileId - DeepSeek file id.
     * @returns the uploader's user id, or `undefined` for a file the relay did not upload.
     */
    fileOwner(fileId: string): string | undefined;
    /**
     * Whether a file was uploaded through the relay by the given employee under the given department.
     * @param fileId - DeepSeek file id.
     * @param userId - the employee's user id.
     * @param departmentId - the department whose key the request uses.
     * @returns `true` when the file belongs to this employee and department.
     */
    fileOwns(fileId: string, userId: string, departmentId: string): boolean;
    /**
     * Latest client IP address and distinct client IP addresses since `since` for each employee.
     * @param since - start of the recent multi-IP window, epoch milliseconds.
     * @returns map from `user_id` to latest address and recent distinct addresses.
     */
    clientAddresses(since: number): Map<string, {
        lastAddress: string;
        recentAddresses: readonly string[];
    }>;
    /**
     * Forget a deleted file.
     * @param fileId - DeepSeek file id.
     */
    forgetFile(fileId: string): void;
    /**
     * Spending totals grouped by employee or department.
     * @param scope - grouping.
     * @param from - inclusive start, epoch milliseconds.
     * @param to - exclusive end, epoch milliseconds.
     * @returns one row per subject with any request in the range.
     */
    spending(scope: QuotaScope, from: number, to: number): SpendingRow[];
    private requireChange;
}
