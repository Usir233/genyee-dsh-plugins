/**
 * DSH request body extensions: top-level fields DSH adds to DeepSeek Messages requests, such as
 * `dsh_plugin_packages` (enabled plugin packages) and `dsh_session_log` (the session's event log).
 * The genyee-keyhub route never forwards them: the employee's loopback proxy removes them before the request
 * leaves the machine, and the admin relay removes any that still arrive.
 */
/**
 * Remove every DSH body extension from a parsed request body, in place.
 * @param body - a JSON object request body.
 * @returns the names of the removed fields.
 */
export declare function removeDshExtensions(body: Record<string, unknown>): string[];
/**
 * Remove every DSH body extension from a serialized request body.
 * @param raw - the request body bytes.
 * @returns the body without extensions, or `raw` unchanged when it is not a JSON object or carries none.
 */
export declare function stripDshExtensions(raw: Buffer): Buffer;
