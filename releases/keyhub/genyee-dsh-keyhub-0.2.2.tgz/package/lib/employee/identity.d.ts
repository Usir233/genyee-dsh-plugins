/**
 * Secret the DSH route presents to the loopback proxy.
 * @param token - the employee's authorization token.
 * @returns 256 bits in base64url; it does not reveal the token.
 */
export declare function proxySecret(token: string): string;
/**
 * Loopback port the proxy tries first.
 * @param installation - text that identifies this DSH installation and plugin row, such as its data directory.
 * @returns a port in 40000–49999.
 */
export declare function proxyPort(installation: string): number;
