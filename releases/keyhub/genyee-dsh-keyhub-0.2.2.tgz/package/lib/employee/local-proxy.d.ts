import type { AccessCode } from '../access-code.ts';
/** A running loopback proxy. */
export interface LocalProxy {
    /** Base URL the DSH route uses, ending in `/anthropic`. */
    readonly baseURL: string;
    /** Stop listening and abort open exchanges. */
    close(): Promise<void>;
}
/** Facilities the proxy needs from its host. */
export interface LocalProxyDependencies {
    /**
     * Read the current access code; called once per request.
     * @returns the decoded access code.
     * @throws Error when the code is missing or malformed; the message is shown to the employee.
     */
    accessCode(): Promise<AccessCode>;
    /**
     * The secret the DSH route currently presents; called once per request.
     * @returns the expected `x-api-key` value.
     */
    secret(): Promise<string>;
    /** Idle timeout of one relay response, in milliseconds. */
    readonly readTimeoutMs: number;
    /** Largest Messages request body read for rewriting, in bytes. */
    readonly maxRequestBytes: number;
    /** Port to listen on first; `0`, or a port in use, falls back to an OS-assigned port. */
    readonly preferredPort: number;
}
/**
 * Start the loopback proxy.
 * @param deps - access code and secret sources, limits, and the preferred port.
 * @returns the running proxy.
 */
export declare function startLocalProxy(deps: LocalProxyDependencies): Promise<LocalProxy>;
